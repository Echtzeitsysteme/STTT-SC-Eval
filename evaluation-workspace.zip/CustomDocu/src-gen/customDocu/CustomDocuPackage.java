/**
 */
package customDocu;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see customDocu.CustomDocuFactory
 * @model kind="package"
 * @generated
 */
public interface CustomDocuPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "customDocu";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/resource/CustomDocu/model/customDocu.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "customDocu";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CustomDocuPackage eINSTANCE = customDocu.impl.CustomDocuPackageImpl.init();

	/**
	 * The meta object id for the '{@link customDocu.impl.FolderImpl <em>Folder</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see customDocu.impl.FolderImpl
	 * @see customDocu.impl.CustomDocuPackageImpl#getFolder()
	 * @generated
	 */
	int FOLDER = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOLDER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Sub Folders</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOLDER__SUB_FOLDERS = 1;

	/**
	 * The feature id for the '<em><b>Docs</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOLDER__DOCS = 2;

	/**
	 * The number of structural features of the '<em>Folder</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOLDER_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Folder</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FOLDER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link customDocu.impl.MethodEntryImpl <em>Method Entry</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see customDocu.impl.MethodEntryImpl
	 * @see customDocu.impl.CustomDocuPackageImpl#getMethodEntry()
	 * @generated
	 */
	int METHOD_ENTRY = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD_ENTRY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Params</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD_ENTRY__PARAMS = 1;

	/**
	 * The number of structural features of the '<em>Method Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD_ENTRY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Method Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METHOD_ENTRY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link customDocu.impl.ParameterImpl <em>Parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see customDocu.impl.ParameterImpl
	 * @see customDocu.impl.CustomDocuPackageImpl#getParameter()
	 * @generated
	 */
	int PARAMETER = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__TYPE = 1;

	/**
	 * The number of structural features of the '<em>Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link customDocu.impl.FileImpl <em>File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see customDocu.impl.FileImpl
	 * @see customDocu.impl.CustomDocuPackageImpl#getFile()
	 * @generated
	 */
	int FILE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE__NAME = 0;

	/**
	 * The number of structural features of the '<em>File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link customDocu.impl.DocFileImpl <em>Doc File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see customDocu.impl.DocFileImpl
	 * @see customDocu.impl.CustomDocuPackageImpl#getDocFile()
	 * @generated
	 */
	int DOC_FILE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__NAME = FILE__NAME;

	/**
	 * The feature id for the '<em><b>Is Interface</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__IS_INTERFACE = FILE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is Enum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__IS_ENUM = FILE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Methods</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__METHODS = FILE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Generalization</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__GENERALIZATION = FILE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Realization</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__REALIZATION = FILE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Fields</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__FIELDS = FILE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Inner Classes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE__INNER_CLASSES = FILE_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the '<em>Doc File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE_FEATURE_COUNT = FILE_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>Doc File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_FILE_OPERATION_COUNT = FILE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link customDocu.impl.FieldEntryImpl <em>Field Entry</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see customDocu.impl.FieldEntryImpl
	 * @see customDocu.impl.CustomDocuPackageImpl#getFieldEntry()
	 * @generated
	 */
	int FIELD_ENTRY = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD_ENTRY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD_ENTRY__TYPE = 1;

	/**
	 * The number of structural features of the '<em>Field Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD_ENTRY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Field Entry</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIELD_ENTRY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link customDocu.impl.DocModelImpl <em>Doc Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see customDocu.impl.DocModelImpl
	 * @see customDocu.impl.CustomDocuPackageImpl#getDocModel()
	 * @generated
	 */
	int DOC_MODEL = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_MODEL__NAME = 0;

	/**
	 * The feature id for the '<em><b>Sub Folders</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_MODEL__SUB_FOLDERS = 1;

	/**
	 * The feature id for the '<em><b>Models</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_MODEL__MODELS = 2;

	/**
	 * The number of structural features of the '<em>Doc Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_MODEL_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Doc Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOC_MODEL_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link customDocu.Folder <em>Folder</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Folder</em>'.
	 * @see customDocu.Folder
	 * @generated
	 */
	EClass getFolder();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.Folder#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see customDocu.Folder#getName()
	 * @see #getFolder()
	 * @generated
	 */
	EAttribute getFolder_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link customDocu.Folder#getSubFolders <em>Sub Folders</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sub Folders</em>'.
	 * @see customDocu.Folder#getSubFolders()
	 * @see #getFolder()
	 * @generated
	 */
	EReference getFolder_SubFolders();

	/**
	 * Returns the meta object for the containment reference list '{@link customDocu.Folder#getDocs <em>Docs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Docs</em>'.
	 * @see customDocu.Folder#getDocs()
	 * @see #getFolder()
	 * @generated
	 */
	EReference getFolder_Docs();

	/**
	 * Returns the meta object for class '{@link customDocu.MethodEntry <em>Method Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Method Entry</em>'.
	 * @see customDocu.MethodEntry
	 * @generated
	 */
	EClass getMethodEntry();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.MethodEntry#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see customDocu.MethodEntry#getName()
	 * @see #getMethodEntry()
	 * @generated
	 */
	EAttribute getMethodEntry_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link customDocu.MethodEntry#getParams <em>Params</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Params</em>'.
	 * @see customDocu.MethodEntry#getParams()
	 * @see #getMethodEntry()
	 * @generated
	 */
	EReference getMethodEntry_Params();

	/**
	 * Returns the meta object for class '{@link customDocu.Parameter <em>Parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parameter</em>'.
	 * @see customDocu.Parameter
	 * @generated
	 */
	EClass getParameter();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.Parameter#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see customDocu.Parameter#getName()
	 * @see #getParameter()
	 * @generated
	 */
	EAttribute getParameter_Name();

	/**
	 * Returns the meta object for the reference '{@link customDocu.Parameter#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Type</em>'.
	 * @see customDocu.Parameter#getType()
	 * @see #getParameter()
	 * @generated
	 */
	EReference getParameter_Type();

	/**
	 * Returns the meta object for class '{@link customDocu.File <em>File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>File</em>'.
	 * @see customDocu.File
	 * @generated
	 */
	EClass getFile();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.File#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see customDocu.File#getName()
	 * @see #getFile()
	 * @generated
	 */
	EAttribute getFile_Name();

	/**
	 * Returns the meta object for class '{@link customDocu.DocFile <em>Doc File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Doc File</em>'.
	 * @see customDocu.DocFile
	 * @generated
	 */
	EClass getDocFile();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.DocFile#isIsInterface <em>Is Interface</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Interface</em>'.
	 * @see customDocu.DocFile#isIsInterface()
	 * @see #getDocFile()
	 * @generated
	 */
	EAttribute getDocFile_IsInterface();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.DocFile#isIsEnum <em>Is Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Enum</em>'.
	 * @see customDocu.DocFile#isIsEnum()
	 * @see #getDocFile()
	 * @generated
	 */
	EAttribute getDocFile_IsEnum();

	/**
	 * Returns the meta object for the containment reference list '{@link customDocu.DocFile#getMethods <em>Methods</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Methods</em>'.
	 * @see customDocu.DocFile#getMethods()
	 * @see #getDocFile()
	 * @generated
	 */
	EReference getDocFile_Methods();

	/**
	 * Returns the meta object for the reference list '{@link customDocu.DocFile#getGeneralization <em>Generalization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Generalization</em>'.
	 * @see customDocu.DocFile#getGeneralization()
	 * @see #getDocFile()
	 * @generated
	 */
	EReference getDocFile_Generalization();

	/**
	 * Returns the meta object for the reference list '{@link customDocu.DocFile#getRealization <em>Realization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Realization</em>'.
	 * @see customDocu.DocFile#getRealization()
	 * @see #getDocFile()
	 * @generated
	 */
	EReference getDocFile_Realization();

	/**
	 * Returns the meta object for the containment reference list '{@link customDocu.DocFile#getFields <em>Fields</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fields</em>'.
	 * @see customDocu.DocFile#getFields()
	 * @see #getDocFile()
	 * @generated
	 */
	EReference getDocFile_Fields();

	/**
	 * Returns the meta object for the reference list '{@link customDocu.DocFile#getInnerClasses <em>Inner Classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Inner Classes</em>'.
	 * @see customDocu.DocFile#getInnerClasses()
	 * @see #getDocFile()
	 * @generated
	 */
	EReference getDocFile_InnerClasses();

	/**
	 * Returns the meta object for class '{@link customDocu.FieldEntry <em>Field Entry</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Field Entry</em>'.
	 * @see customDocu.FieldEntry
	 * @generated
	 */
	EClass getFieldEntry();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.FieldEntry#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see customDocu.FieldEntry#getName()
	 * @see #getFieldEntry()
	 * @generated
	 */
	EAttribute getFieldEntry_Name();

	/**
	 * Returns the meta object for the reference '{@link customDocu.FieldEntry#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Type</em>'.
	 * @see customDocu.FieldEntry#getType()
	 * @see #getFieldEntry()
	 * @generated
	 */
	EReference getFieldEntry_Type();

	/**
	 * Returns the meta object for class '{@link customDocu.DocModel <em>Doc Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Doc Model</em>'.
	 * @see customDocu.DocModel
	 * @generated
	 */
	EClass getDocModel();

	/**
	 * Returns the meta object for the attribute '{@link customDocu.DocModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see customDocu.DocModel#getName()
	 * @see #getDocModel()
	 * @generated
	 */
	EAttribute getDocModel_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link customDocu.DocModel#getSubFolders <em>Sub Folders</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sub Folders</em>'.
	 * @see customDocu.DocModel#getSubFolders()
	 * @see #getDocModel()
	 * @generated
	 */
	EReference getDocModel_SubFolders();

	/**
	 * Returns the meta object for the containment reference list '{@link customDocu.DocModel#getModels <em>Models</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Models</em>'.
	 * @see customDocu.DocModel#getModels()
	 * @see #getDocModel()
	 * @generated
	 */
	EReference getDocModel_Models();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CustomDocuFactory getCustomDocuFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link customDocu.impl.FolderImpl <em>Folder</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see customDocu.impl.FolderImpl
		 * @see customDocu.impl.CustomDocuPackageImpl#getFolder()
		 * @generated
		 */
		EClass FOLDER = eINSTANCE.getFolder();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FOLDER__NAME = eINSTANCE.getFolder_Name();

		/**
		 * The meta object literal for the '<em><b>Sub Folders</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FOLDER__SUB_FOLDERS = eINSTANCE.getFolder_SubFolders();

		/**
		 * The meta object literal for the '<em><b>Docs</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FOLDER__DOCS = eINSTANCE.getFolder_Docs();

		/**
		 * The meta object literal for the '{@link customDocu.impl.MethodEntryImpl <em>Method Entry</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see customDocu.impl.MethodEntryImpl
		 * @see customDocu.impl.CustomDocuPackageImpl#getMethodEntry()
		 * @generated
		 */
		EClass METHOD_ENTRY = eINSTANCE.getMethodEntry();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METHOD_ENTRY__NAME = eINSTANCE.getMethodEntry_Name();

		/**
		 * The meta object literal for the '<em><b>Params</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference METHOD_ENTRY__PARAMS = eINSTANCE.getMethodEntry_Params();

		/**
		 * The meta object literal for the '{@link customDocu.impl.ParameterImpl <em>Parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see customDocu.impl.ParameterImpl
		 * @see customDocu.impl.CustomDocuPackageImpl#getParameter()
		 * @generated
		 */
		EClass PARAMETER = eINSTANCE.getParameter();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__NAME = eINSTANCE.getParameter_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PARAMETER__TYPE = eINSTANCE.getParameter_Type();

		/**
		 * The meta object literal for the '{@link customDocu.impl.FileImpl <em>File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see customDocu.impl.FileImpl
		 * @see customDocu.impl.CustomDocuPackageImpl#getFile()
		 * @generated
		 */
		EClass FILE = eINSTANCE.getFile();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FILE__NAME = eINSTANCE.getFile_Name();

		/**
		 * The meta object literal for the '{@link customDocu.impl.DocFileImpl <em>Doc File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see customDocu.impl.DocFileImpl
		 * @see customDocu.impl.CustomDocuPackageImpl#getDocFile()
		 * @generated
		 */
		EClass DOC_FILE = eINSTANCE.getDocFile();

		/**
		 * The meta object literal for the '<em><b>Is Interface</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOC_FILE__IS_INTERFACE = eINSTANCE.getDocFile_IsInterface();

		/**
		 * The meta object literal for the '<em><b>Is Enum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOC_FILE__IS_ENUM = eINSTANCE.getDocFile_IsEnum();

		/**
		 * The meta object literal for the '<em><b>Methods</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOC_FILE__METHODS = eINSTANCE.getDocFile_Methods();

		/**
		 * The meta object literal for the '<em><b>Generalization</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOC_FILE__GENERALIZATION = eINSTANCE.getDocFile_Generalization();

		/**
		 * The meta object literal for the '<em><b>Realization</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOC_FILE__REALIZATION = eINSTANCE.getDocFile_Realization();

		/**
		 * The meta object literal for the '<em><b>Fields</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOC_FILE__FIELDS = eINSTANCE.getDocFile_Fields();

		/**
		 * The meta object literal for the '<em><b>Inner Classes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOC_FILE__INNER_CLASSES = eINSTANCE.getDocFile_InnerClasses();

		/**
		 * The meta object literal for the '{@link customDocu.impl.FieldEntryImpl <em>Field Entry</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see customDocu.impl.FieldEntryImpl
		 * @see customDocu.impl.CustomDocuPackageImpl#getFieldEntry()
		 * @generated
		 */
		EClass FIELD_ENTRY = eINSTANCE.getFieldEntry();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FIELD_ENTRY__NAME = eINSTANCE.getFieldEntry_Name();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FIELD_ENTRY__TYPE = eINSTANCE.getFieldEntry_Type();

		/**
		 * The meta object literal for the '{@link customDocu.impl.DocModelImpl <em>Doc Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see customDocu.impl.DocModelImpl
		 * @see customDocu.impl.CustomDocuPackageImpl#getDocModel()
		 * @generated
		 */
		EClass DOC_MODEL = eINSTANCE.getDocModel();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOC_MODEL__NAME = eINSTANCE.getDocModel_Name();

		/**
		 * The meta object literal for the '<em><b>Sub Folders</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOC_MODEL__SUB_FOLDERS = eINSTANCE.getDocModel_SubFolders();

		/**
		 * The meta object literal for the '<em><b>Models</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOC_MODEL__MODELS = eINSTANCE.getDocModel_Models();

	}

} //CustomDocuPackage
