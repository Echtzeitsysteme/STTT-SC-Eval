/**
 */
package customDocu.impl;

import customDocu.CustomDocuPackage;
import customDocu.DocFile;
import customDocu.FieldEntry;
import customDocu.MethodEntry;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Doc File</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link customDocu.impl.DocFileImpl#isIsInterface <em>Is Interface</em>}</li>
 *   <li>{@link customDocu.impl.DocFileImpl#isIsEnum <em>Is Enum</em>}</li>
 *   <li>{@link customDocu.impl.DocFileImpl#getMethods <em>Methods</em>}</li>
 *   <li>{@link customDocu.impl.DocFileImpl#getGeneralization <em>Generalization</em>}</li>
 *   <li>{@link customDocu.impl.DocFileImpl#getRealization <em>Realization</em>}</li>
 *   <li>{@link customDocu.impl.DocFileImpl#getFields <em>Fields</em>}</li>
 *   <li>{@link customDocu.impl.DocFileImpl#getInnerClasses <em>Inner Classes</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DocFileImpl extends FileImpl implements DocFile {
	/**
	 * The default value of the '{@link #isIsInterface() <em>Is Interface</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsInterface()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_INTERFACE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsInterface() <em>Is Interface</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsInterface()
	 * @generated
	 * @ordered
	 */
	protected boolean isInterface = IS_INTERFACE_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsEnum() <em>Is Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsEnum()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_ENUM_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsEnum() <em>Is Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsEnum()
	 * @generated
	 * @ordered
	 */
	protected boolean isEnum = IS_ENUM_EDEFAULT;

	/**
	 * The cached value of the '{@link #getMethods() <em>Methods</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMethods()
	 * @generated
	 * @ordered
	 */
	protected EList<MethodEntry> methods;

	/**
	 * The cached value of the '{@link #getGeneralization() <em>Generalization</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneralization()
	 * @generated
	 * @ordered
	 */
	protected EList<DocFile> generalization;

	/**
	 * The cached value of the '{@link #getRealization() <em>Realization</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRealization()
	 * @generated
	 * @ordered
	 */
	protected EList<DocFile> realization;

	/**
	 * The cached value of the '{@link #getFields() <em>Fields</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFields()
	 * @generated
	 * @ordered
	 */
	protected EList<FieldEntry> fields;

	/**
	 * The cached value of the '{@link #getInnerClasses() <em>Inner Classes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInnerClasses()
	 * @generated
	 * @ordered
	 */
	protected EList<DocFile> innerClasses;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DocFileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CustomDocuPackage.Literals.DOC_FILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsInterface() {
		return isInterface;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsInterface(boolean newIsInterface) {
		boolean oldIsInterface = isInterface;
		isInterface = newIsInterface;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CustomDocuPackage.DOC_FILE__IS_INTERFACE, oldIsInterface, isInterface));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsEnum() {
		return isEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsEnum(boolean newIsEnum) {
		boolean oldIsEnum = isEnum;
		isEnum = newIsEnum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CustomDocuPackage.DOC_FILE__IS_ENUM, oldIsEnum, isEnum));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MethodEntry> getMethods() {
		if (methods == null) {
			methods = new EObjectContainmentEList<MethodEntry>(MethodEntry.class, this, CustomDocuPackage.DOC_FILE__METHODS);
		}
		return methods;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DocFile> getGeneralization() {
		if (generalization == null) {
			generalization = new EObjectResolvingEList<DocFile>(DocFile.class, this, CustomDocuPackage.DOC_FILE__GENERALIZATION);
		}
		return generalization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DocFile> getRealization() {
		if (realization == null) {
			realization = new EObjectResolvingEList<DocFile>(DocFile.class, this, CustomDocuPackage.DOC_FILE__REALIZATION);
		}
		return realization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<FieldEntry> getFields() {
		if (fields == null) {
			fields = new EObjectContainmentEList<FieldEntry>(FieldEntry.class, this, CustomDocuPackage.DOC_FILE__FIELDS);
		}
		return fields;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DocFile> getInnerClasses() {
		if (innerClasses == null) {
			innerClasses = new EObjectResolvingEList<DocFile>(DocFile.class, this, CustomDocuPackage.DOC_FILE__INNER_CLASSES);
		}
		return innerClasses;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case CustomDocuPackage.DOC_FILE__METHODS:
			return ((InternalEList<?>) getMethods()).basicRemove(otherEnd, msgs);
		case CustomDocuPackage.DOC_FILE__FIELDS:
			return ((InternalEList<?>) getFields()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CustomDocuPackage.DOC_FILE__IS_INTERFACE:
			return isIsInterface();
		case CustomDocuPackage.DOC_FILE__IS_ENUM:
			return isIsEnum();
		case CustomDocuPackage.DOC_FILE__METHODS:
			return getMethods();
		case CustomDocuPackage.DOC_FILE__GENERALIZATION:
			return getGeneralization();
		case CustomDocuPackage.DOC_FILE__REALIZATION:
			return getRealization();
		case CustomDocuPackage.DOC_FILE__FIELDS:
			return getFields();
		case CustomDocuPackage.DOC_FILE__INNER_CLASSES:
			return getInnerClasses();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CustomDocuPackage.DOC_FILE__IS_INTERFACE:
			setIsInterface((Boolean) newValue);
			return;
		case CustomDocuPackage.DOC_FILE__IS_ENUM:
			setIsEnum((Boolean) newValue);
			return;
		case CustomDocuPackage.DOC_FILE__METHODS:
			getMethods().clear();
			getMethods().addAll((Collection<? extends MethodEntry>) newValue);
			return;
		case CustomDocuPackage.DOC_FILE__GENERALIZATION:
			getGeneralization().clear();
			getGeneralization().addAll((Collection<? extends DocFile>) newValue);
			return;
		case CustomDocuPackage.DOC_FILE__REALIZATION:
			getRealization().clear();
			getRealization().addAll((Collection<? extends DocFile>) newValue);
			return;
		case CustomDocuPackage.DOC_FILE__FIELDS:
			getFields().clear();
			getFields().addAll((Collection<? extends FieldEntry>) newValue);
			return;
		case CustomDocuPackage.DOC_FILE__INNER_CLASSES:
			getInnerClasses().clear();
			getInnerClasses().addAll((Collection<? extends DocFile>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CustomDocuPackage.DOC_FILE__IS_INTERFACE:
			setIsInterface(IS_INTERFACE_EDEFAULT);
			return;
		case CustomDocuPackage.DOC_FILE__IS_ENUM:
			setIsEnum(IS_ENUM_EDEFAULT);
			return;
		case CustomDocuPackage.DOC_FILE__METHODS:
			getMethods().clear();
			return;
		case CustomDocuPackage.DOC_FILE__GENERALIZATION:
			getGeneralization().clear();
			return;
		case CustomDocuPackage.DOC_FILE__REALIZATION:
			getRealization().clear();
			return;
		case CustomDocuPackage.DOC_FILE__FIELDS:
			getFields().clear();
			return;
		case CustomDocuPackage.DOC_FILE__INNER_CLASSES:
			getInnerClasses().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CustomDocuPackage.DOC_FILE__IS_INTERFACE:
			return isInterface != IS_INTERFACE_EDEFAULT;
		case CustomDocuPackage.DOC_FILE__IS_ENUM:
			return isEnum != IS_ENUM_EDEFAULT;
		case CustomDocuPackage.DOC_FILE__METHODS:
			return methods != null && !methods.isEmpty();
		case CustomDocuPackage.DOC_FILE__GENERALIZATION:
			return generalization != null && !generalization.isEmpty();
		case CustomDocuPackage.DOC_FILE__REALIZATION:
			return realization != null && !realization.isEmpty();
		case CustomDocuPackage.DOC_FILE__FIELDS:
			return fields != null && !fields.isEmpty();
		case CustomDocuPackage.DOC_FILE__INNER_CLASSES:
			return innerClasses != null && !innerClasses.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (isInterface: ");
		result.append(isInterface);
		result.append(", isEnum: ");
		result.append(isEnum);
		result.append(')');
		return result.toString();
	}

} //DocFileImpl
