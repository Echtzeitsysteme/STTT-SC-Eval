/**
 */
package customDocu;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Doc File</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link customDocu.DocFile#isIsInterface <em>Is Interface</em>}</li>
 *   <li>{@link customDocu.DocFile#isIsEnum <em>Is Enum</em>}</li>
 *   <li>{@link customDocu.DocFile#getMethods <em>Methods</em>}</li>
 *   <li>{@link customDocu.DocFile#getGeneralization <em>Generalization</em>}</li>
 *   <li>{@link customDocu.DocFile#getRealization <em>Realization</em>}</li>
 *   <li>{@link customDocu.DocFile#getFields <em>Fields</em>}</li>
 *   <li>{@link customDocu.DocFile#getInnerClasses <em>Inner Classes</em>}</li>
 * </ul>
 *
 * @see customDocu.CustomDocuPackage#getDocFile()
 * @model
 * @generated
 */
public interface DocFile extends File {
	/**
	 * Returns the value of the '<em><b>Is Interface</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Interface</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Interface</em>' attribute.
	 * @see #setIsInterface(boolean)
	 * @see customDocu.CustomDocuPackage#getDocFile_IsInterface()
	 * @model default="false"
	 * @generated
	 */
	boolean isIsInterface();

	/**
	 * Sets the value of the '{@link customDocu.DocFile#isIsInterface <em>Is Interface</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Interface</em>' attribute.
	 * @see #isIsInterface()
	 * @generated
	 */
	void setIsInterface(boolean value);

	/**
	 * Returns the value of the '<em><b>Is Enum</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Is Enum</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Enum</em>' attribute.
	 * @see #setIsEnum(boolean)
	 * @see customDocu.CustomDocuPackage#getDocFile_IsEnum()
	 * @model default="false"
	 * @generated
	 */
	boolean isIsEnum();

	/**
	 * Sets the value of the '{@link customDocu.DocFile#isIsEnum <em>Is Enum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Enum</em>' attribute.
	 * @see #isIsEnum()
	 * @generated
	 */
	void setIsEnum(boolean value);

	/**
	 * Returns the value of the '<em><b>Methods</b></em>' containment reference list.
	 * The list contents are of type {@link customDocu.MethodEntry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Methods</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Methods</em>' containment reference list.
	 * @see customDocu.CustomDocuPackage#getDocFile_Methods()
	 * @model containment="true"
	 * @generated
	 */
	EList<MethodEntry> getMethods();

	/**
	 * Returns the value of the '<em><b>Generalization</b></em>' reference list.
	 * The list contents are of type {@link customDocu.DocFile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Generalization</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Generalization</em>' reference list.
	 * @see customDocu.CustomDocuPackage#getDocFile_Generalization()
	 * @model
	 * @generated
	 */
	EList<DocFile> getGeneralization();

	/**
	 * Returns the value of the '<em><b>Realization</b></em>' reference list.
	 * The list contents are of type {@link customDocu.DocFile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Realization</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Realization</em>' reference list.
	 * @see customDocu.CustomDocuPackage#getDocFile_Realization()
	 * @model
	 * @generated
	 */
	EList<DocFile> getRealization();

	/**
	 * Returns the value of the '<em><b>Fields</b></em>' containment reference list.
	 * The list contents are of type {@link customDocu.FieldEntry}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fields</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fields</em>' containment reference list.
	 * @see customDocu.CustomDocuPackage#getDocFile_Fields()
	 * @model containment="true"
	 * @generated
	 */
	EList<FieldEntry> getFields();

	/**
	 * Returns the value of the '<em><b>Inner Classes</b></em>' reference list.
	 * The list contents are of type {@link customDocu.DocFile}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Inner Classes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inner Classes</em>' reference list.
	 * @see customDocu.CustomDocuPackage#getDocFile_InnerClasses()
	 * @model
	 * @generated
	 */
	EList<DocFile> getInnerClasses();

} // DocFile
