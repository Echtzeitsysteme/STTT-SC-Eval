package org.emoflon.ibex.tgg.run.modiscoibextgg.delta;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import org.emoflon.modisco.java.ClassDeclaration;
import org.emoflon.modisco.java.Model;
import org.emoflon.modisco.java.Package;
import org.emoflon.modisco.java.Type;
import org.emoflon.modisco.java.emf.JavaFactory;


public class ModiscoDeltaHelper {

	private ModiscoExplorer explorer;
	private Random r;
	
	public ModiscoDeltaHelper(ModiscoExplorer explorer) {
		this.explorer = explorer;
		r = new Random();
	}
	
	public ModiscoDeltaHelper(ModiscoExplorer explorer, int seed) {
		this.explorer = explorer;
		r = new Random(seed);
	}
	
	public Model createNewModel() {
		Model m = JavaFactory.eINSTANCE.createModel();
		explorer.model.eResource().getContents().add(m);
		m.setName(explorer.model.getName());
		m.getArchives().addAll(explorer.model.getArchives());
		m.getClassFiles().addAll(explorer.model.getClassFiles());
		m.getOrphanTypes().addAll(explorer.model.getOrphanTypes());
		m.getCompilationUnits().addAll(explorer.model.getCompilationUnits());
		m.getOwnedElements().addAll(explorer.model.getOwnedElements());
		m.getUnresolvedItems().addAll(explorer.model.getUnresolvedItems());
		return m;
	}
	
	public boolean moveLeafPackage() {
		List<Package> packages = new ArrayList<>();
		for(Package p : explorer.allPackages) {
			if(p.getOwnedPackages().size() != 0)
				continue;
			
			packages.add(p);
		}
		
		Package found = packages.get(new Random().nextInt(packages.size()));
		for(Package p : explorer.allPackages) {
//			if(!(p.eContainer() instanceof Package))
//					continue;
			
			p.getOwnedPackages().add(found);
			return true;
		}
		return false;
	}
	
	public boolean movePackage(int depth) {
		for(Package p : explorer.allPackages) {
			if(!p.getOwnedPackages().isEmpty())
				continue;
			
			Package subP = getPackage(p, depth - 1);
			if(subP == null)
				continue;
			
			ModiscoExplorer newExplorer = new ModiscoExplorer();
			newExplorer.exploreModiscoPackage(subP);
			
			if(newExplorer.allPackages.size() >= Math.pow(5, depth)) {
				continue;
			}
			
			if(subP.eContainer() instanceof Package) 
				newExplorer.allPackages.add((Package) subP.eContainer());
			
			for(Package newRoot : explorer.allPackages) {
				if(newExplorer.allPackages.contains(newRoot))
					continue;
				
				if(newRoot.getName().equals("(default package)")) {
					continue;
				}
				
				newRoot.getOwnedPackages().add(subP);
				System.err.println(newExplorer.allPackages.size());
				return true;
			}
		}
		return false;
	}
	
	public Package getPackage(Package p, int depth) {
		if(depth == 0) {
			return p;
		}
		
		if(p.eContainer() instanceof Package) {
			return getPackage((Package) p.eContainer(), depth - 1);
		}
		
		return null;
	}
	
	public void moveClass() {
		Optional<Type> cd = explorer.allTypes.stream().filter(t -> t instanceof ClassDeclaration).findAny();
		if(cd.isPresent()) {
			for(Package p : explorer.allPackages) {
				ClassDeclaration c = (ClassDeclaration) cd.get();
				if(p.equals(c.getPackage()) || p.getName().equals("(default package)")) 
					continue;
				
				p.getOwnedElements().add(c);
				return;
			}
		}
	}
	
	public void createNewRootPackage() {
		Package p = JavaFactory.eINSTANCE.createPackage();
		p.setName(explorer.model.getName());
		explorer.model.getOwnedElements().add(p);
		p.getOwnedPackages().addAll(
			explorer.model.getOwnedElements()
			.stream()
			.filter(e -> !e.equals(p))
			.collect(Collectors.toList()));
	}
	
	private boolean movePackage(Package p) {
		if(r.nextInt(explorer.allPackages.size()) == 0)
			return movePackageToModel(p);	
		else
			return movePackageToPackage(p);
	}
	
	private boolean movePackageToModel(Package pkg) {
		if(pkg.eContainer().equals(explorer.model))
			return movePackageToPackage(pkg);
		
		System.out.println("Moving package " + pkg.getName()+ "(" + pkg.hashCode() + ") to Model");
		explorer.model.getOwnedElements().add(pkg);
		return true;
	}
	
	private boolean movePackageToPackage(Package pkg) {
		List<Package> allPackages =  new ArrayList<>();
		allPackages.addAll(explorer.allPackages);
		
		Collection<Package> toBeMoved = findMovedPackages(pkg);
		allPackages.removeAll(toBeMoved);
		if(allPackages.size() < 2)
			return false;
					
		
		Package destPkg = null;
		do {
			destPkg = allPackages.get(r.nextInt(allPackages.size()));
		} while(destPkg.equals(pkg));
		
		System.out.println("Moving package " + pkg.getName() + "(" + pkg.hashCode() + ") to package " + destPkg.getName() + "(" + destPkg.hashCode() + ")");
		
		destPkg.getOwnedPackages().add(pkg);
		return true;
	}
	
	private Collection<Package> findMovedPackages(Package pkg) {
		Collection<Package> movedPackages = new ArrayList<>();
		findMovedPackages(pkg, movedPackages);
		return movedPackages;
	}
	
	private void findMovedPackages(Package pkg, Collection<Package> movedPackages) {
		movedPackages.add(pkg);
		pkg.getOwnedPackages().forEach(p -> findMovedPackages(p, movedPackages));
	}
}
