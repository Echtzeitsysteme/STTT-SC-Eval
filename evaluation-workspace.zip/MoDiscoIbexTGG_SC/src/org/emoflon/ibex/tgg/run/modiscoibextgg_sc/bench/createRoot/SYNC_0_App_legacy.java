package org.emoflon.ibex.tgg.run.modiscoibextgg_sc.bench.createRoot;

import java.io.IOException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.emoflon.ibex.tgg.compiler.patterns.FilterNACStrategy;
import org.emoflon.ibex.tgg.operational.defaults.IbexOptions;
import org.emoflon.ibex.tgg.operational.strategies.sync.SYNC;
import org.emoflon.ibex.tgg.run.modiscoibextgg.delta.ModiscoDeltaHelper;
import org.emoflon.ibex.tgg.run.modiscoibextgg.delta.ModiscoExplorer;
import org.emoflon.ibex.tgg.run.modiscoibextgg_sc._RegistrationHelper;
import org.emoflon.ibex.tgg.runtime.engine.DemoclesTGGEngine;
import org.emoflon.modisco.java.Model;
import org.emoflon.modisco.java.emf.impl.JavaPackageImpl;
import customDocu.impl.CustomDocuPackageImpl;

public class SYNC_0_App_legacy extends SYNC {
 
	private static final int[] tests = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
	private static final int i = 0;
	private static final int DELTAS = 1;
	
	public SYNC_0_App_legacy() throws IOException {
		super(createIbexOptions());
		registerBlackInterpreter(new DemoclesTGGEngine());
	}

	public static void main(String[] args) throws IOException {
		BasicConfigurator.configure();
		Logger.getRootLogger().setLevel(Level.INFO);

		SYNC_0_App_legacy sync = new SYNC_0_App_legacy();
		
		logger.info("Starting Batch");
		long tic = System.currentTimeMillis();
		sync.forward();
		long toc = System.currentTimeMillis();
		logger.info("Completed Batch in: " + (toc - tic) + " ms");
		
		ModiscoExplorer explorer = new ModiscoExplorer().exploreModiscoModel((Model) sync.getSourceResource().getContents().get(0));
		ModiscoDeltaHelper deltaHelper = new ModiscoDeltaHelper(explorer);
		
		logger.info("Starting SYNC ...");
		long longTic = System.currentTimeMillis();
		for(int i = 0; i < DELTAS; i++) {
			tic = System.currentTimeMillis();
			Model m  = deltaHelper.createNewModel();
			sync.forward();
			EcoreUtil.delete(explorer.model, true);
			explorer.model = m;
			sync.forward();
			toc = System.currentTimeMillis();
			logger.info("Applied Delta in: " + (toc - tic) + " ms");
		}
		long longToc = System.currentTimeMillis();
		logger.info("Finished SYNC in: " + (longToc - longTic) + " ms");
		
		sync.saveModels();
		sync.terminate();
	}
	
	@Override
	public void loadModels() throws IOException {
		s = loadResource(options.projectPath() + "/instances/" + tests[i] +  "/src.xmi");
		t = createResource(options.projectPath() + "/instances/trg.xmi");
		c = createResource(options.projectPath() + "/instances/corr.xmi");
		p = createResource(options.projectPath() + "/instances/protocol.xmi");
		
		EcoreUtil.resolveAll(rs);
	}
	
	
//	@Override
	protected void registerUserMetamodels() throws IOException {
//		_RegistrationHelper.registerMetamodels(rs, this);

		rs.getPackageRegistry().put("platform:/plugin/org.eclipse.gmt.modisco.java/model/java.ecore", JavaPackageImpl.init());
		rs.getPackageRegistry().put("platform:/resource/CustomDocu/model/customDocu.ecore", CustomDocuPackageImpl.init());
		
		// Register correspondence metamodel last
		loadAndRegisterCorrMetamodel(options.projectPath() + "/model/" + options.projectName() + ".ecore");
	}
	
	private static IbexOptions createIbexOptions() {
		return _RegistrationHelper.createIbexOptions().debug(false).repairUsingShortcutRules(false);
	}
}
