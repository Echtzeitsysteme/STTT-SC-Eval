package org.emoflon.ibex.tgg.run.modiscoibextgg.delta;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.emoflon.modisco.java.*;
import org.emoflon.modisco.java.Package;

public class ModiscoExplorer {
	
	public Model model;
	public List<Package> allPackages;
	public List<Type> allTypes;
	public List<MethodDeclaration> allMethodDeclarations;
	public List<VariableDeclaration> allVariableDeclarations;
	public List<TypeAccess> allTypeAccesses;
	public List<FieldDeclaration> allFieldDeclaration;
	
	public ModiscoExplorer() {
		allPackages = new ArrayList<>();
		allTypes = new ArrayList<>();
		allMethodDeclarations = new ArrayList<>();
		allVariableDeclarations = new ArrayList<>();
		allTypeAccesses = new ArrayList<>();
		allFieldDeclaration = new ArrayList<>();
	}
	
	public ModiscoExplorer exploreModiscoModel(Model model) {
		this.model = model;
		model.getOwnedElements().forEach(this::exploreModiscoPackage);
		model.getOrphanTypes().forEach(this::exploreModiscoType);
		
//		System.err.println("----------------");
//		System.err.println("allPackages: " + allPackages.size());
//		System.err.println("allTypes: " + allTypes.size());
//		System.err.println("allMethodDeclarations: " + allMethodDeclarations.size());
//		System.err.println("allVariableDeclarations: " + allVariableDeclarations.size());
//		System.err.println("allTypeAccesses: " + allTypeAccesses.size());
//		System.err.println("allFieldDeclaration: " + allFieldDeclaration.size());
//		System.err.println("----------------");

		return this;
	}
	
	public void exploreModiscoPackage(Package pkg) {
		add(allPackages, pkg);
		pkg.getOwnedPackages().forEach(this::exploreModiscoPackage);
		pkg.getOwnedElements().forEach(this::exploreModiscoType);
	}
	
	private void exploreModiscoType(Type type) {
		add(allTypes, type);
		
		if(type instanceof ClassDeclaration) 
			exploreModiscoClassDeclaration((ClassDeclaration) type);
		if(type instanceof InterfaceDeclaration)
			exploreModiscoInterfaceDeclaration((InterfaceDeclaration) type);
		if(type instanceof AbstractTypeDeclaration)
			exploreModiscoAbstractTypeDeclaration((AbstractTypeDeclaration) type);
	}
	
	private void exploreModiscoClassDeclaration(ClassDeclaration cDeclaration) {
		add(allTypes, cDeclaration);
		cDeclaration.getBodyDeclarations().stream().filter(b -> b instanceof ClassDeclaration).map(b -> (ClassDeclaration) b).forEach(this::exploreModiscoClassDeclaration);
		exploreModiscoTypeAccess(cDeclaration.getSuperClass());
		cDeclaration.getSuperInterfaces().forEach(this::exploreModiscoTypeAccess);
	}
	
	private void exploreModiscoInterfaceDeclaration(InterfaceDeclaration iDeclaration) {
		add(allTypes, iDeclaration);
		iDeclaration.getSuperInterfaces().forEach(this::exploreModiscoTypeAccess);
	}
	
	private void exploreModiscoAbstractTypeDeclaration(AbstractTypeDeclaration aDeclaration) {
		aDeclaration.getBodyDeclarations().stream().filter(b -> b instanceof MethodDeclaration).map(b -> (MethodDeclaration) b).forEach(this::exploreModiscoMethodDeclaration);
		aDeclaration.getBodyDeclarations().stream().filter(b -> b instanceof FieldDeclaration).map(b -> (FieldDeclaration) b).forEach(this::exploreModiscoFieldDeclaration);
	}
	
	private void exploreModiscoMethodDeclaration(MethodDeclaration mDeclaration) {
		add(allMethodDeclarations, mDeclaration);
		exploreModiscoTypeAccess(mDeclaration.getReturnType());
		mDeclaration.getParameters().forEach(this::exploreModiscoVariableDeclaration);
	}
	
	private void exploreModiscoFieldDeclaration(FieldDeclaration fDeclaration) {
		add(allFieldDeclaration, fDeclaration);
		exploreModiscoTypeAccess(fDeclaration.getType());
	}
	
	private void exploreModiscoTypeAccess(TypeAccess access) {
		add(allTypeAccesses, access);
	}
	
	private void exploreModiscoVariableDeclaration(VariableDeclaration vDeclaration) {
		add(allVariableDeclarations, vDeclaration);
		
		if(vDeclaration instanceof SingleVariableDeclaration)
			exploreModiscoSingleVariableDeclaration((SingleVariableDeclaration) vDeclaration);
	}
	
	private void exploreModiscoSingleVariableDeclaration(SingleVariableDeclaration sDeclaration) {
		exploreModiscoTypeAccess(sDeclaration.getType());
	}
	
	private <T> void add(Collection<T> coll, T elt) {
		if(coll.contains(elt))
			return;
		coll.add(elt);
	}
}
