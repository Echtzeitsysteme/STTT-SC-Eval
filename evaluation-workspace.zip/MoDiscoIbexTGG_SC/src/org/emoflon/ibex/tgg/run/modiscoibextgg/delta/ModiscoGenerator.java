package org.emoflon.ibex.tgg.run.modiscoibextgg.delta;

import java.util.ArrayList;
import java.util.Collection;

import org.emoflon.ibex.tgg.util.LoremIpsum;
import org.emoflon.modisco.java.ClassDeclaration;
import org.emoflon.modisco.java.Model;
import org.emoflon.modisco.java.Package;
import org.emoflon.modisco.java.emf.JavaFactory;

public class ModiscoGenerator {

	public ModiscoGenerator() {
	}
	
	public Model generateModiscoModel(int packageDepth, int packageCount) {
		Model m = JavaFactory.eINSTANCE.createModel();
		m.setName("MyProject");
		m.getOwnedElements().addAll(generateModiscoPackages(packageDepth, packageCount));
		return m;
	}
	
	public Collection<Package> generateModiscoPackages(int packageDepth, int packageCount) {
		if(packageDepth == 0)
			return new ArrayList<>();
		
		Collection<Package> packages = new ArrayList<>();
		for(int i = 0; i < packageCount; i++) {
			Package p = JavaFactory.eINSTANCE.createPackage();
			p.setName(packageDepth + "_" + i + "_" + LoremIpsum.getInstance().randomWord());
			if(packageDepth == 1)
				p.getOwnedElements().addAll(generateModiscoClasses(packageCount));
			p.getOwnedPackages().addAll(generateModiscoPackages(packageDepth - 1, packageCount));
			packages.add(p);
		}
		return packages;
	}
	
	public Collection<ClassDeclaration> generateModiscoClasses(int packageCount) {
		Collection<ClassDeclaration> classes = new ArrayList<>();
		for(int i = 0; i < packageCount; i++) {
			ClassDeclaration cd = JavaFactory.eINSTANCE.createClassDeclaration();
			cd.setName(i + "_" + LoremIpsum.getInstance().randomWord());
			classes.add(cd);
		}
		return classes;
	}
}
